type ..\cfg\Interface.ini

java -classpath ../bin/wdserver.jar;../bin/WDFramework.jar;../bin/WDFEmulador.jar;../bin/EJBUtil.jar;../bin/MiddConnector2.jar;../bin/commons-io-1.4.jar;../bin/commons-httpclient-3.1.jar;../bin/commons-logging-1.1.1.jar;../bin/commons-codec-1.3.jar;../bin/Base64.jar ar.com.wd.wdServer ../cfg/WDFEmulador_env.ini